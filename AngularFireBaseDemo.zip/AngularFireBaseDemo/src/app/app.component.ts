import { Component, OnInit } from '@angular/core';


import { FbDataService } from './fb-data.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';

  items$: Observable<any[]>;
  itemName = '';
  itemNames = '';

  constructor(private fbdataService: FbDataService) {

  }

  ngOnInit() {
    this.items$ = this.fbdataService.read();
  }

  addData() {
    if(this.itemName != ''){
      // alert(this.itemName);
      this.fbdataService.create(this.itemName);
    }
    else{
      alert("Add Text...");
    }
  }

  updateData(key) {
    this.fbdataService.update(key);
  }

  deleteData(key) {
    this.fbdataService.delete(key);
  }

}
